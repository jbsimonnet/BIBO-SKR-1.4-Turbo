The "byte_ascii.fon" is the bitmap fonts of ASCII, size: 8*16

The "word_unicode.fon" is the bitmap fonts of UTF-16, size: 16*16

Scan direction: form UP to DOWN, from LEFT to RIGHT
